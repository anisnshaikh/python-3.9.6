#pylint: disable=bad-continuation,missing-docstring

TEST_TUPLE = ('a', 'b'  # [implicit-str-concat-in-sequence]
              'c')
