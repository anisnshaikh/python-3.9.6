# pylint: disable=missing-docstring
from __future__ import print_function
__revision__ = 0

try:
    __revision__ += 1
except Exception: # [broad-except]
    print('error')


try:
    __revision__ += 1
except BaseException: # [broad-except]
    print('error')
